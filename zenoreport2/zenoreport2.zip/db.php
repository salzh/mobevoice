<?php
/**
 * Created by Parth Mudgal.
 * Date: 8/9/12
 * Time: 11:24 PM
 */


return array(
    'zenofon' => array(
        'host'=>"127.0.0.1",
        'username'=>"root",
        'password'=>"",
        'dbname'=>"multilevel"
    ),
    'zenoradio'=>array(
        'host'=>'127.0.0.1',
        'username'=>"radio",
        'password'=>'radio',
        'dbname'=>'radio'
    ),
    'www-zenoradio'=>array(
        'host'=>'127.0.0.1',
        'username'=>'root',
        'password'=>'',
        'dbname'=>'www-zenoradio-com'
    )
);

/*
return array(
    'zenofon' => array(
        'host' => 'localhost',
        'user' => 'root',
        "pass" => "",
        'dbname' => 'multilevel'
    ),
    'zenoradio' => array(
        'host' => "localhost",
        "user" => "root",
        "pass" => "",
        "dbname" => "radio"
    ),
    'new_radio' => array(
        'host' => "localhost",
        "user" => "root",
        "pass" => "",
        "dbname" => "new_radio"
    ),
    'podcast' => array(
        'host' => "localhost",
        "user" => "root",
        "pass" => "",
        "dbname" => "podcast"
    ),
    'ZJ_1' => array(
        'host' => "localhost",
        "user" => "root",
        "pass" => "",
        "dbname" => "sbcorpor_zeno"
    ),
    'ZJ_2' => array(
        'host' => "localhost",
        "user" => "root",
        "pass" => "",
        "dbname" => "www-zenoradio-com"
    ),
    'Zenoradio_3' => array(
        'host' => "localhost",
        "user" => "root",
        "pass" => "",
        "dbname" => "zenoradio-v2"
    )
);

*/