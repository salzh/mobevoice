/**
 * Created with JetBrains PhpStorm.
 * User: Pheonix
 * Date: 9/29/12
 * Time: 6:04 AM
 * To change this template use File | Settings | File Templates.
 */

Ext.define('Zenoreport.model.Schemas', {
    extend:'Ext.data.Model',
    fields:[
        {name:'SchemaName', type:'string'}
    ]
});