/**
 * Created with JetBrains PhpStorm.
 * User: Pheonix
 * Date: 9/29/12
 * Time: 6:03 AM
 * To change this template use File | Settings | File Templates.
 */

Ext.define('Zenoreport.model.Schema', {
    extend:'Ext.data.Model',
    fields:[
        {name:'TableName', type:'string'}
    ]
});