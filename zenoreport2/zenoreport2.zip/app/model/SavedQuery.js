/**
 * Created with JetBrains PhpStorm.
 * User: Pheonix
 * Date: 9/29/12
 * Time: 5:46 AM
 * To change this template use File | Settings | File Templates.
 */

Ext.define("Zenoreport.model.SavedQuery", {
    extend:'Ext.data.Model',
    fields:[
        {name:'name', type:'string'}
    ]
});